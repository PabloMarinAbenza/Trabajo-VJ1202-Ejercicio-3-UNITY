using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Proyectil : MonoBehaviour
{
    Rigidbody2D rigidbody2d;

    public bool puededisparar = true;        //Comprueba si jugador puede disparar

    void Awake()                        //Llamamos a "Start" antes de la actualizaci�n del primer frame
    {
        rigidbody2d = GetComponent<Rigidbody2D>();          //Generamos RigidBody2D del personaje
    }

    void Update()                       //Llamamos a "Update" una vez por frame
    {
        if (transform.position.magnitude > 1000.0f)
        {

            Destroy(gameObject);     //Si se aleja demasiado el proyectil, se autodestruye para evitar que se mueva infinitamente
        }
    }

    public void Disparar(Vector2 direccion, float fuerza)
    {
        rigidbody2d.AddForce(direccion * fuerza);
    }

    void OnCollisionEnter2D(Collision2D tocar)
    {
        ControlEnemigo enem = tocar.collider.GetComponent<ControlEnemigo>();

        if (enem != null) enem.Muerte();    //Si golpea a enemigo, muere

        Destroy(gameObject);
    }
}
