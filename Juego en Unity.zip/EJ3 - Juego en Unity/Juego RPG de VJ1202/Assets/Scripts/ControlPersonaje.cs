using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControlPersonaje : MonoBehaviour
{
    public float velocidad = 4.0f;      //Velocidad a la que se mueve el jugador

    Vector2 comprobarDireccion = new Vector2(0, -1);   //Generamos vector para comprobar en qu� direcci�n se mueve el personaje
    Animator animator;                             //Generamos variable para animatores del personaje
    Rigidbody2D rigidbody2d;                           //Generamos RigidBody2D del personaje

    public float vida { get { return vidaActual; } }        //Vida con la que se calculan los cambios. Adopta valor de vida actual
    public float vidaMaxima = 3.0f;
    public float vidaActual;       //Hacemos 2 variables, una que indica la vida m�xima del jugador, y otra para la actual

    public bool invencible;                //Indica si el jugador no recibe da�o
    public float tiempoInvencible;         //Adopta el valor del tiempo de espera
    public float tiempoEsperaInvencible = 3.0f;     //Indica por cu�nto tiempo no recibe da�o

    public GameObject proyectilPrefab;      //Generamos el objeto proyectil que crearemos cuando el jugador dispare

    AudioSource sonido;         //Generamos la fuente de sonido del personaje donde se reproducen los clips
    public AudioClip lanzarProyectil;       //Sonido de disparar un proyectil
    public AudioClip grito;

    void Start()                        //Llamamos a "Start" antes de la actualizaci�n del primer frame
    {
        rigidbody2d = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();       //Inicializamos en el personaje la animator y el cuerpo

        vidaActual = vidaMaxima;       //Establecemos el valor de la vida actual

        sonido = GetComponent<AudioSource>();     //Inicializamos la fuente de sonido
    }

    void Update()                       //Llamamos a "Update" una vez por frame
    {
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");         //Generamos variables de tipo flotante "Horizontal" y "Vertical"

        Vector2 mover = new Vector2(horizontal, vertical);     //Asociamos las direcciones al vector

        if (!Mathf.Approximately(mover.x, 0.0f) || !Mathf.Approximately(mover.y, 0.0f))     //Verificamos que X e Y no son iguales a 0
        {
            comprobarDireccion.Set(mover.x, mover.y);
            comprobarDireccion.Normalize();
        }

        animator.SetFloat("Mirar X", comprobarDireccion.x);
        animator.SetFloat("Mirar Y", comprobarDireccion.y);
        animator.SetFloat("Velocidad", mover.magnitude);       //Asociamos comprobaciones del vector "comprobarDireccion"

        Vector2 posicion = rigidbody2d.position;
        posicion = posicion + mover * velocidad * Time.deltaTime;
        rigidbody2d.MovePosition(posicion);                        //Acualizamos posicion del personaje

        if (invencible)         //Comrpobamos si el jugador es inmune
        {
            tiempoInvencible -= Time.deltaTime;                 //El tiempo de espera se va acabando
            if (tiempoInvencible < 0) invencible = false;       //Si el tiempo llega a 0, el jugador no es inmune
        }

        //Comprobar si el jugador dispara o no

        if ((Input.GetKeyDown(KeyCode.C)))   //Presionar tecla C para disparar
        {
            Disparar();     //LLama a la acci�n disparar
            sonido.PlayOneShot(lanzarProyectil);    //Reproduce el sonido de disparar cuando presiona C
            sonido.PlayOneShot(grito);
        }


    }

    public void CambioVida(float cantidad)          //M�todo para actualizar la vida del jugador
    {
        if (cantidad < 0)
        {
            if (invencible) return;         //Devolver si jugador no puede recibir da�o

            invencible = true;
            tiempoInvencible = tiempoEsperaInvencible;      //Si puede recibir da�o, hacerlo inmune unos segundos hasta volver a poder
        }

        vidaActual = Mathf.Clamp(vidaActual + cantidad, 0.0f, vidaMaxima);

        if (vidaActual == 2.5f) BarraVida.instance.SetValue(0.81f);
        else if (vidaActual == 0.5f) BarraVida.instance.SetValue(0.187f);
        else BarraVida.instance.SetValue(vidaActual / (float)vidaMaxima);    
    }

    void Disparar()             //Accion de disparar del jugador. Presiona C y dispara proyectil
    {

        GameObject proyectilObject = Instantiate(proyectilPrefab, rigidbody2d.position + Vector2.up * 0.5f, Quaternion.identity);

        Proyectil proyectil = proyectilObject.GetComponent<Proyectil>();

        proyectil.Disparar(comprobarDireccion, 300);

    }

    public void PlaySound(AudioClip clip)       //M�todo para reproducir los sonidos que queramos
    {
        sonido.PlayOneShot(clip);           //Reproducir sonido una sola vez

    }
}
