using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DropCorazon : MonoBehaviour
{
    public ParticleSystem efectoCorazon;

    public AudioClip recogerCorazon;

    void Start()
    {
        efectoCorazon.Stop();
    }

    void OnTriggerEnter2D(Collider2D tocar)
    {
        ControlPersonaje jugador = tocar.GetComponent<ControlPersonaje>();

        if (jugador != null)
        {
            if (jugador.vida < jugador.vidaMaxima)      //Si el jugador toca el objeto cuando su vida actual es baja
            {
                jugador.CambioVida(1.0f);           //Aumenta la vida en 1 
                efectoCorazon.Play();
                jugador.PlaySound(recogerCorazon);      //Reproduce el sonido del corazon cuando el jugador toque el objeto
                gameObject.SetActive(false);           //El objeto curativo con Trigger se destruye

            }
        }
    }
}
