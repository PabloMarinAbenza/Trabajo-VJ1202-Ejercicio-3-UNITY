using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControlEnemigo : MonoBehaviour
{

    public float velocidad = 3.0f;      //Velocidad a la que se mueve el enemigo
    public bool vertical;               //Comprueba si se mueve en vertical o no
    public float tiempoCambio = 3.0f;    //Tiempo en el que cambia de direcci�n

    Rigidbody2D rigidbody2d;
    Animator animator;              //Creamos el rigidbody2d para el movimiento y el animator para las animaciones

    float tiempo;
    int direccion = 1;              //Direccion en la que se mueve

    public ParticleSystem efectoMuerte;

    public AudioClip daño;
    public AudioClip queja;
    public AudioClip morir;

    void Start()                        //Llamamos a "Start" antes de la actualizaci�n del primer frame
    {
        rigidbody2d = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();       //Inicializamos en el personaje la animator y el cuerpo

        tiempo = tiempoCambio;          //Establecemos que el temporizador tenga el valor del tiempo entre cada cambio

        efectoMuerte.Stop();
    }

    void Update()                       //Llamamos a "Update" una vez por frame
    {
        tiempo -= Time.deltaTime;      //El tiempo de espera se va acabando 

        if (tiempo < 0)
        {
            direccion = -direccion;
            tiempo = tiempoCambio;      //Cuando llegue a 0, cambia la direccion y el tiempo de cambio se resetea
        }

        Vector2 posicion = GetComponent<Rigidbody2D>().position;        //Establecemos que la posicion del enemigo sea la del rigidbody2D asociado

        if (vertical)
        {
            posicion.y = posicion.y + Time.deltaTime * velocidad * direccion;
            animator.SetFloat("Mirar X", 0);
            animator.SetFloat("Mirar Y", direccion);        //Si vertical es TRUE, el enemigo se mueve sobre el eje Y con su animacion
        }
        else
        {
            posicion.x = posicion.x + Time.deltaTime * velocidad * direccion;
            animator.SetFloat("Mirar X", direccion);
            animator.SetFloat("Mirar Y", 0);        //Si vertical es FALSE, el enemigo se mueve sobre el eje X con su animacion
        }

        GetComponent<Rigidbody2D>().MovePosition(posicion);         //Se actualiza la posici�n del personaje
    }

    void OnCollisionEnter2D(Collision2D tocar)      //M�todo para da�ar al jugador
    {
        ControlPersonaje jugador = tocar.gameObject.GetComponent<ControlPersonaje>();

        if (jugador != null)
        {
            jugador.CambioVida(-1.0f);      //Si el jugador toca al enemigo, la vida baja en 1
            jugador.PlaySound(daño);
            jugador.PlaySound(queja);
        }
    }

    public void Muerte()
    {
        efectoMuerte.Play();
        gameObject.SetActive(false);           //El enemigo muere
    }
}
