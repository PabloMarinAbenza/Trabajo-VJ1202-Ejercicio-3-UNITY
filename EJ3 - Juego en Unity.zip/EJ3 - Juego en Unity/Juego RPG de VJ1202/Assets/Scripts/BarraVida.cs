using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BarraVida : MonoBehaviour
{
    public static BarraVida instance { get; private set; }
    public Image mascara;
    float anchuraOriginal;


    void Awake()
    {
        instance = this;
    }

    void Start()                        //Llamamos a "Start" antes de la actualizaci�n del primer frame
    {
        anchuraOriginal = mascara.rectTransform.rect.width;
    }

    public void SetValue(float valor)
    {
        mascara.rectTransform.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, anchuraOriginal * valor);
    }
}
