using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Proyectil : MonoBehaviour
{
    Rigidbody2D rigidbody2d;

    private ParticleSystem efectoRomper;

    private float delay = 0.6f;

    public AudioClip romper;

    public ControlPersonaje jugador;

    void Awake()                        //Llamamos a "Start" antes de la actualizaci�n del primer frame
    {
        rigidbody2d = GetComponent<Rigidbody2D>();          //Generamos RigidBody2D del personaje
        efectoRomper = GetComponent<ParticleSystem>();
        efectoRomper.Stop();
        jugador = GameObject.FindWithTag("Player").GetComponent<ControlPersonaje>();
    }

    void Update()                       //Llamamos a "Update" una vez por frame
    {
        if (transform.position.magnitude > 1000.0f)
        {
            jugador.PlaySound(romper);
            efectoRomper.Play();
            SpriteRenderer sr = GetComponent<SpriteRenderer>();
            sr.enabled = false;
            gameObject.SetActive(false);
            jugador.contador--;
        }
    }

    public void Disparar(Vector2 direccion, float fuerza)
    {
        rigidbody2d.AddForce(direccion * fuerza);
    }

    void OnCollisionEnter2D(Collision2D tocar)
    {
        if (tocar.gameObject.GetComponent<ControlEnemigo>() != null)            //Metemos en funcion y comprobamos si toca
        {
            ControlEnemigo enem = tocar.gameObject.GetComponent<ControlEnemigo>();          //Asocias el script a un objeto "enemigo"          
            jugador.PlaySound(romper);
            efectoRomper.Play();
            SpriteRenderer sr = GetComponent<SpriteRenderer>();
            sr.enabled = false;
            enem.Muerte();                                          //El enemigo muere
        }
        else
        {
            jugador.PlaySound(romper);
            efectoRomper.Play();
            SpriteRenderer sr = GetComponent<SpriteRenderer>();
            sr.enabled = false;
        }
        Destroy(gameObject, delay);
        jugador.contador--;
    }
}
